// darkag-ai-worker.js
// Cloudflare Worker — Secure proxy for Anthropic API
// Deploy at: workers.cloudflare.com

export default {
  async fetch(request, env) {

    // CORS — allow your domain only
    const allowedOrigins = [
      'https://darkag.org',
      'https://www.darkag.org',
      'http://localhost:3000',  // for testing
    ];

    const origin = request.headers.get('Origin') || '';
    const isAllowed = allowedOrigins.includes(origin);

    const corsHeaders = {
      'Access-Control-Allow-Origin': isAllowed ? origin : 'https://darkag.org',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    };

    // Handle preflight
    if (request.method === 'OPTIONS') {
      return new Response(null, { headers: corsHeaders });
    }

    // Only allow POST
    if (request.method !== 'POST') {
      return new Response('Method not allowed', { status: 405 });
    }

    try {
      const body = await request.json();
      const { messages } = body;

      if (!messages || !Array.isArray(messages)) {
        return new Response(JSON.stringify({ error: 'Invalid request' }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      // Call Anthropic API — key is secret in Worker env
      const response = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': env.ANTHROPIC_API_KEY,
          'anthropic-version': '2023-06-01',
        },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 1000,
          system: `You are DarkAG's expert cybersecurity AI assistant. DarkAG is a professional cybersecurity office specializing in anti-blackmail/extortion cases, account recovery, digital forensics, and cybersecurity consulting. The founder has credentials from Israel's elite 8200 Academy and an honorary PhD in cybersecurity.

Your role:
1. Detect the user's language (Arabic, Hebrew, or English) from their first message and ALWAYS respond in that SAME language
2. Be warm, empathetic, and professional — victims are often in distress
3. Provide immediate actionable advice
4. For urgent cases direct to: +972586682260 or darkag@darkag.computer
5. NEVER help attackers — only help victims
6. Keep responses concise (3-5 sentences), use bullet points for clarity
7. Platforms covered: Instagram, Facebook, WhatsApp, TikTok, Snapchat, YouTube, Telegram, Twitter/X, PUBG, Gmail, LinkedIn, Discord and all others

Emergency: +972586682260 | darkag@darkag.computer | darkag.org`,
          messages: messages,
        }),
      });

      const data = await response.json();

      return new Response(JSON.stringify(data), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });

    } catch (err) {
      return new Response(JSON.stringify({ error: 'Server error' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }
  },
};
