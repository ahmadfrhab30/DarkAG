// darkag-contact-worker.js
// Cloudflare Worker — Contact Form → Email via Resend (free tier: 3000 emails/month)
// Setup: resend.com → get API key → add as env variable RESEND_API_KEY

export default {
  async fetch(request, env) {

    const corsHeaders = {
      'Access-Control-Allow-Origin': 'https://darkag.org',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    };

    if (request.method === 'OPTIONS') {
      return new Response(null, { headers: corsHeaders });
    }

    if (request.method !== 'POST') {
      return new Response('Method not allowed', { status: 405 });
    }

    try {
      const body = await request.json();
      const { name, contact, caseType, message, urgency, lang } = body;

      // Urgency emoji
      const urgencyEmoji = urgency === 'urgent' ? '🚨' : urgency === 'high' ? '⚠️' : '📋';
      const urgencyLabel = urgency === 'urgent' ? 'URGENT' : urgency === 'high' ? 'HIGH' : 'MEDIUM';

      // Send email via Resend
      const emailRes = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${env.RESEND_API_KEY}`,
        },
        body: JSON.stringify({
          from: 'DarkAG Contact <noreply@darkag.org>',
          to: ['darkag@darkag.computer'],
          subject: `${urgencyEmoji} [${urgencyLabel}] حالة جديدة من الموقع — ${caseType}`,
          html: `
<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
<meta charset="UTF-8">
<style>
  body { font-family: 'Courier New', monospace; background: #030a06; color: #e8f5ec; margin: 0; padding: 20px; }
  .container { max-width: 600px; margin: 0 auto; border: 1px solid rgba(0,255,136,0.3); border-radius: 8px; overflow: hidden; }
  .header { background: #0d1f12; padding: 20px; border-bottom: 1px solid rgba(0,255,136,0.2); }
  .logo { color: #00ff88; font-size: 20px; font-weight: 700; letter-spacing: 3px; }
  .logo span { color: #e8f5ec; }
  .badge { display: inline-block; padding: 4px 12px; border-radius: 3px; font-size: 11px; font-weight: 700; margin-top: 8px; letter-spacing: 1px; }
  .badge-urgent { background: rgba(255,61,61,0.2); color: #ff3d3d; border: 1px solid rgba(255,61,61,0.4); }
  .badge-high { background: rgba(255,183,0,0.2); color: #ffb700; border: 1px solid rgba(255,183,0,0.4); }
  .badge-medium { background: rgba(0,255,136,0.1); color: #00ff88; border: 1px solid rgba(0,255,136,0.3); }
  .body { padding: 24px; }
  .field { margin-bottom: 16px; }
  .field-label { font-size: 10px; color: #4a7a58; letter-spacing: 2px; margin-bottom: 4px; }
  .field-value { font-size: 14px; color: #e8f5ec; background: #0d1f12; padding: 10px 14px; border-radius: 4px; border: 1px solid rgba(0,255,136,0.15); }
  .message-box { background: #0d1f12; border: 1px solid rgba(0,255,136,0.2); border-radius: 6px; padding: 16px; margin-top: 16px; font-size: 14px; line-height: 1.8; color: #8fb89a; white-space: pre-wrap; }
  .footer { background: #060f09; padding: 16px 24px; border-top: 1px solid rgba(0,255,136,0.15); font-size: 11px; color: #4a7a58; text-align: center; }
  .cta { display: inline-block; margin: 8px; padding: 10px 20px; background: #00ff88; color: #030a06; text-decoration: none; border-radius: 4px; font-weight: 700; font-size: 12px; }
</style>
</head>
<body>
<div class="container">
  <div class="header">
    <div class="logo"><span>DARK</span>AG</div>
    <div>
      <span class="badge badge-${urgency}">${urgencyEmoji} ${urgencyLabel} PRIORITY</span>
    </div>
  </div>
  <div class="body">
    <div class="field">
      <div class="field-label">// TIMESTAMP</div>
      <div class="field-value">${new Date().toLocaleString('ar-SA', { timeZone: 'Asia/Jerusalem' })} (IL)</div>
    </div>
    <div class="field">
      <div class="field-label">// CASE TYPE</div>
      <div class="field-value">${caseType || 'غير محدد'}</div>
    </div>
    <div class="field">
      <div class="field-label">// CLIENT NAME</div>
      <div class="field-value">${name || 'مجهول'}</div>
    </div>
    <div class="field">
      <div class="field-label">// CONTACT INFO</div>
      <div class="field-value">${contact || 'لم يُقدَّم'}</div>
    </div>
    <div class="field">
      <div class="field-label">// LANG</div>
      <div class="field-value">${lang || 'ar'}</div>
    </div>
    <div class="field-label" style="margin-top:20px">// CASE DESCRIPTION</div>
    <div class="message-box">${message || 'لا يوجد وصف'}</div>
    <div style="text-align:center;margin-top:24px">
      <a href="tel:+972586682260" class="cta">📞 اتصل الآن</a>
      <a href="mailto:${contact?.includes('@') ? contact : 'darkag@darkag.computer'}" class="cta" style="background:#0d1f12;color:#00ff88;border:1px solid rgba(0,255,136,0.3)">✉ رد بإيميل</a>
    </div>
  </div>
  <div class="footer">
    DarkAG Cybersecurity Office · darkag.org · +972 58 668 2260
  </div>
</div>
</body>
</html>`,
        }),
      });

      if (!emailRes.ok) {
        const err = await emailRes.text();
        console.error('Resend error:', err);
        return new Response(JSON.stringify({ success: false, error: 'Email failed' }), {
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      return new Response(JSON.stringify({ success: true }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });

    } catch (err) {
      return new Response(JSON.stringify({ success: false, error: 'Server error' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }
  },
};
